# -*- coding: utf-8 -*-
from blueapps.core.celery.celery import app as celery_app # noqa
